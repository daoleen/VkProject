/**
 * Created by alex on 12.6.14.
 */
public class User {
//    private Long id;
//    private String first_name;
//    private String last_name;
//    private Integer sex;
//    private String domain;
//    private String screen_name;
//    private City city;
//    private Country country;
//    private String photo_50;
//    private String photo_100;
//    private String photo_200;
//    private String photo_max;
//    private String photo_200_orig;
//    private String photo_max_orig;
//    private Integer has_mobile;
//    private Integer online;
//    private Integer cat_post;
//    private Integer can_see_all_posts;
//    private Integer can_see_audio;
//    private Integer cat_write_private_message;
//    private String site;
//    private String status;
//    private LastSeen last_seen;
//    private Integer common_count;
//    private Counters counters;
//    private Integer university;
//    private String university_name;
//    private Integer faculty;
//    private String faculty_name;
//    private Integer graduation;
//    private Integer relation;
//    private List<University> universities;
//    private List<School> schools;
//    private List<Relative> relatives;
}
